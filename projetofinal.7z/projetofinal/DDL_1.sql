create schema PM;
use PM;
create table logins(
matricula varchar(9) primary key,
phierarquica varchar(8) not null,
nome_de_guerra varchar (100) not null,
senha varchar(20) not null
);
create table ocorrencias(
matricula varchar(9),
id  bigint primary key,
num_bo bigint, 
cidade enum('Vitória da Conquista','Anagé'),
bairro enum('Alto Panorama','Bruno Barcelar','Cruzeiro'),
logradouro enum('Rua Alice Pedral','Rua Antonio Dantas','Av.2 de Julho'),
numero bigint,
ano_bo enum ('2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016'),
mes_bo enum('Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'),
dia_bo enum('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'),
tipificaçao_da_ocorrencia enum ('Atentado ao Pudor','Ameaça','Homicídio'),
nome_do_envolvido varchar(255),
ano_nasc enum ('1994','1995','1996','1997','1998','1999','2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016'),
mes_nasc enum('Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'),
dia_nasc enum('01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31'),
envolvimento enum('Testemunha','Autor','Vítima','Outros'),
foreign key(matricula) references logins(matricula)
);