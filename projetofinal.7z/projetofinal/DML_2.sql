insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('123456789','SD','Billy the Kid','pliftplaftspliu');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('456951456','SD','CrissyTiroCerto','xablau');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('789852357','SD','AlahuAkbar','olar123');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('651489236','SD','Jhony Bravo','05091995');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('754125965','SD','Chuck Norris','123456');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('852456753','SD','Rambo','12a5v456s');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('985657842','SD','MainADCTemplarHimyname','hiiiiii');
insert into logins(matricula,phierarquica,nome_de_guerra,senha) 
values ('963759486','SD','Willy','qqqqqqqq');