<?php

//session_start();

include_once("conexao.php");



if((isset($_GET["buscar"])) ){
    $buscar = mysqli_real_escape_string($conn, $_GET["buscar"]);
    
    
    
    $sql = "SELECT * FROM cw_insercao WHERE matricula = '$buscar'";
   
    $result = mysqli_query($conn, $sql);
    $resultado = mysqli_fetch_assoc($result);
    
    //echo $result;
    echo $resultado;
    
    var_dump($sql);
    var_dump($resul);
    var_dump($resultado);
    //echo $sql;
    
    if(empty($resultado)){
          
        
      //  $_SESSION['loginErro'] = "ERRO DE LOGIN";  
        header("Location: error.php");
         
        "erro de login";
      }  
        else {
            
            header("Location: resultado.php");
            echo "login com banco sucessooooo";
        }
}
    
        
        
        
    else{
        
        header ("Location: error.php");
        "O campo nao pode ficar VAZIO";
        $_SESSION['loginErro'] = "O campo nao pode ficar VAZIO";
    }
?>