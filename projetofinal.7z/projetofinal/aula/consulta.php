<!DOCTYPE html>
<html lang="pt-BR">
    
    <head>
        <meta charset="utf-8">
        <title>CONSULTA</title>
        
    </head>
    
    <body>
        
        <form name="frmBusca" method="get" action= "valida3.php">
            <input type="text" name="buscar" />
            <input type="submit" value="Buscar" />
        </form>
        
        
        
        </body>

        </html>
