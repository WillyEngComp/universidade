<?php

session_start();

?>

<!DOCTYPE html>
<html lang="pt-BR">
    
    <head>
        <meta charset="utf-8">
        <title>HOME_INDEX</title>
        
    </head>
    
    <body>
        
<link rel="stylesheet" href="style.css" media="screen">
<form name="frmLogin" method="post" action= "valida.php">
<div class="imgcontainer">
    
</div>

    <br><br><br>
        
 <center> <div class="container">
   <center> <label><b>Matricula: </b></label>
    <input type="text" id = "nome" placeholder="  Insira a matricula" name="uname" required> <br><br></center>

   <center> <label><b>Senha: </b></label>
    <input type="password" id = "senha" placeholder=" Insira a senha" name="psw" required></center> <br>

    <button type="submit">Acessar</button>
    
     
  </div>
</center>
       
</form>
        
        
        
        
        
        </body>

        </html>
