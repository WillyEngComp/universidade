<?php

session_start();

include_once("conexao.php");

if((isset($_POST['uname'])) and (isset($_POST['psw']))){
    $login = mysqli_real_escape_string($conn, $_POST['uname']);
    $senha = mysqli_real_escape_string($conn, $_POST['psw']);
    //$senha = md5($senha);
    //echo "diferente de vazio";
    
    $sql = "SELECT * FROM cw_usuarios WHERE matricula = '$login' and senha = '$senha'";
    $result = mysqli_query($conn, $sql);
    $resultado = mysqli_fetch_assoc($result);
    
    
    
    if(empty($resultado)){
          
        
        $_SESSION['loginErro'] = "ERRO DE LOGIN";  
        header("Location: error.php");
        
        "erro de login";
      }  
        else {
            
            header("Location: home.php");
            "login com banco sucessooooo";
        }
}
    
        
        
        
    else{
        
        header ("Location: error.php");
        "O campo nao pode ficar VAZIO";
        $_SESSION['loginErro'] = "O campo nao pode ficar VAZIO";
    }
?>