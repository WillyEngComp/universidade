<?php

session_start();

?>

<!DOCTYPE html>
<html lang="pt-BR">
    
    <head>
        <meta charset="utf-8">
        <title>INSERIR DADOS</title>
        
    </head>
    
    <body>
 <link rel="stylesheet" href="style.css" media="screen">
        <form name="frmInsercao" method="get" action= "valida2.php">
<div class ="insercao"> 
    <center>
 <!-- Primeiro row de textareas 3 -->
Numero do b.o: <br><input type="text" id="bo" name="nbo" rows="1" cols="16"><br>

        Cidade: <br><input type="text" name="cidade" list="exampleList1">
        <datalist id="exampleList1">
            <option value="Anage">
            <option value="Vitoria da Conquista">
  
 </datalist><br>
Bairro: <br>
        <input type="text" name="bairro" list="exampleList2">
<datalist id="exampleList2">
    <option value="Alto Maron">
    <option value="Bruno Barcelar">
        <option value="Cruzeiro">
                
</datalist>
        
        
        
Logradouro: <br><input type="text" name="logradouro" list="exampleList3">
        <datalist id="exampleList3">
      
    <option value="Rua Alice Pedral">
  <option value="Rua Antonio Dantas">
    <option value="Av. 2 de Julho">
        </datalist>
    
  
 <br>
Numero: <br><input type="text" name="numero" rows="1" cols="16">


<br>Dia: <br><input type="text" name="dia" list="exampleList4">
  <datalist id="exampleList4">
  <option value="1">
  <option value="2">
  <option value="3">
  <option value="4">
  <option value="5">
  <option value="6">
  <option value="7">
  <option value="8">
  <option value="9">
  <option value="10">
  <option value="11">
  <option value="12">
  <option value="13">
  <option value="14">
  <option value="15">
  <option value="16">
  <option value="17">
  <option value="18">
  <option value="19">
  <option value="20">
  <option value="21">
  <option value="22">
  <option value="23">
  <option value="24">
  <option value="25">
  <option value="26">
  <option value="27">
  <option value="28">
  <option value="29">
  <option value="30">
  <option value="31">
 </datalist>
 
 Mes: <input type="text" name="mes" list="exampleList5">
  <datalist id="exampleList5">
  
  <option value="1">Janeiro</option>
  <option value="2">Fevereiro</option>
  <option value="3">Marco</option>
  <option value="4">Abril</option>
  <option value="5">Maio</option>
  <option value="6">Junho</option>
  <option value="7">Julho</option>
  <option value="8">Agosto</option>
  <option value="9">Setembro</option>
  <option value="10">Outubro</option>
  <option value="11">Novembro</option>
  <option value="12">Dezembro</option>
        </datalist>
 Ano: <input type="text" name="ano" list="exampleList6">
  <datalist id="exampleList6">
  
  <option value="2016">
  <option value="2017">
        </datalist>
 <br>
Tipificacao da ocorrencia: <br><input type="text" name="tipooc" list="exampleList7">
  <datalist id="exampleList7">
  <option value="Antentado ao pudor">
  <option value="Ameaça">
  <option value="Homicídio">
  <option value="Roubo">
        </datalist>

<br>Nome do envolvido: <br><input type="text" name="nomeenv" rows="1" cols="16">
        
<br>Dia de nascimento: <br><input type="text" name="dianasc" list="exampleList8">
        <datalist id="exampleList8">
 <option value="1">
  <option value="2">
  <option value="3">
  <option value="4">
  <option value="5">
  <option value="6">
  <option value="7">
  <option value="8">
  <option value="9">
  <option value="10">
  <option value="11">
  <option value="12">
  <option value="13">
  <option value="14">
  <option value="15">
  <option value="16">
  <option value="17">
  <option value="18">
  <option value="19">
  <option value="20">
  <option value="21">
  <option value="22">
  <option value="23">
  <option value="24">
  <option value="25">
  <option value="26">
  <option value="27">
  <option value="28">
  <option value="29">
  <option value="30">
  <option value="31">
        
        </datalist>
  
 
 <br>Mes de Nascimento: <input type="text" name="mesnasc" list="exampleList9">
  <datalist id="exampleList9">
  
  <option value="1">Janeiro</option>
  <option value="2">Fevereiro</option>
  <option value="3">Marco</option>
  <option value="4">Abril</option>
  <option value="5">Maio</option>
  <option value="6">Junho</option>
  <option value="7">Julho</option>
  <option value="8">Agosto</option>
  <option value="9">Setembro</option>
  <option value="10">Outubro</option>
  <option value="11">Novembro</option>
  <option value="12">Dezembro</option>
        </datalist>
 <br>Ano de Nascimento: <input type="text" name="anonasc" list="exampleList10">
  <datalist id="exampleList10">
  
  <option value="1900">
  <option value="1901">
      <option value="1910">
          <option value="1911">
              <option value="1981">
                  <option value="2000">
                      <option value="2016">
        </datalist>
        
<br>Envolvimento: <br><input type="text" name="envolvimento" list="exampleList11">
  <datalist id="exampleList11">
  <option value="Testemunha">
  <option value="Autor"> 
  <option value="Vítima">
  <option value="Outros">
      
        </datalist> <br>
    MATRÍCULA PM CMT: <br><input type="text" name="matricula" list="exampleList12">
  <datalist id="exampleList12">
  <option value="307010001">Alisson </option>
  <option value="306550022">Carvalho</option>
  <option value="308000007">Vinicius</option>
  <option value="305267058">Willy</option>
        </datalist><br>
<button type ="submit" id="inser">INSERIR </button>
    
     
  </div>
</center>
       
</form>
        
        
        
        
        
        </body>

        </html>















