<?php
    $DB_HOSTNAME    = 'localhost';
    $DB_USERNAME    ='root';
    $DB_PASSWORD    = '6930';
    $DB_DATABASE    = 'video-aula';
    
    $conn = mysqli_connect($DB_HOSTNAME, $DB_USERNAME, $DB_PASSWORD, $DB_DATABASE);
    if(!$conn)
        die("falha na conexao: ".mysqli_connect_error());
        else
            echo "conexao realizada com sucesso";



?>
