<?php

//session_start();

include_once("conexao.php");



if((isset($_GET["dia"])) and (isset($_GET["mes"]))){
    $numerobo = mysqli_real_escape_string($conn, $_GET["nbo"]);
    $cidadebo = mysqli_real_escape_string($conn, $_GET["cidade"]);
    $bairrobo = mysqli_real_escape_string($conn, $_GET["bairro"]);
    $logradourobo = mysqli_real_escape_string($conn, $_GET["logradouro"]);
    $numerolocalbo = mysqli_real_escape_string($conn, $_GET["numero"]);
    $diabo = mysqli_real_escape_string($conn, $_GET["dia"]);
    $mesbo = mysqli_real_escape_string($conn, $_GET["mes"]);
    $anobo = mysqli_real_escape_string($conn, $_GET["ano"]);
    $tipobo = mysqli_real_escape_string($conn, $_GET["tipooco"]);
    $envolvidobo = mysqli_real_escape_string($conn, $_GET["nomeenv"]);
    $diaenv1bo = mysqli_real_escape_string($conn, $_GET["dianasc"]);
    $mesenv1bo = mysqli_real_escape_string($conn, $_GET["mesnasc"]);
    $anoenv1bo = mysqli_real_escape_string($conn, $_GET["anonasc"]);
    $tipoenvbo = mysqli_real_escape_string($conn, $_GET["envolvimento"]);
    $matricula = mysqli_real_escape_string($conn, $_GET["matricula"]);
    
    //$senha = md5($senha);
    //echo "diferente de vazio";
    
    //$sql = "SELECT * FROM cw_insercao WHERE numerobo = '$numerobo' and bairrobo = '$bairrobo'";
    $sql = "INSERT INTO `cw_insercao` (`id`, `numerobo`, `cidadebo`, `bairrobo`, `logradourobo`, `numerolocalbo`, `diabo`, `mesbo`, `anobo`, `tipobo`, `envolvido1bo`, `diaenv1bo`, `mesenv1bo`, `anoenv1bo`, `tipoenvbo`, `matricula`) VALUES (DEFAULT, '$numerobo', '$cidadebo', '$bairrobo', '$logradourobo', '$numerolocalbo', '$diabo', '$mesbo', '$anobo', '$tipobo', '$envolvidobo', '$diaenv1bo', '$mesenv1bo', '$anoenv1bo', '$tipoenvbo', '$matricula')";
    $result = mysqli_query($conn, $sql);
    $resultado = mysqli_fetch_assoc($result);
    
    
    
    
    if(empty($resultado)){
          
        
      //  $_SESSION['loginErro'] = "ERRO DE LOGIN";  
        header("Location: final.php");
         
        //"erro de login";
      }  
        else {
            
            header("Location: final.php");
          //  "login com banco sucessooooo";
        }
}
    
        
        
        
    else{
        
        header("Location: final.php");
        //"O campo nao pode ficar VAZIO";
        //$_SESSION['loginErro'] = "O campo nao pode ficar VAZIO";
    }
?>