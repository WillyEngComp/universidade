

<link rel="stylesheet" href="style.css" media="screen">

  <div class="imgcontainer">
    <center><img src="C:\Users\raira\Desktop\header-pm.png" ></center>
  </div>
<br><br><br>
 <center> <div class="container-2">
 <div class="popup" onclick="myFunction()">
   <span class="popuptext" id="myPopup">
  <button type ="submit" onclick=window.location.href="formBusAnimal.php"> GERAR PLANILHA DE DADOS </button>
  <button type ="submit"> PRODUTIVIDADE </button>
  <button type ="submit"> DENÚNCIAS/REGISTROS </button>
  <button type ="submit"> GRÁFICOS MENOR/MAIOR </button>
  <button type ="submit"> CONSULTAR ROPs </button>
  <button type ="submit"> LIVRO DE PARTE - ADJUN </button>
  <button type ="submit"> CARTÃO PROGRAMA </button>
  
  
    </span>
  <button type ="submit"> CONSULTAR ROP </button></div></span>
   <button type ="submit" onclick=window.location.href="final.php"> INSERIR DADOS </button>
   <button type ="submit"> TELEFONES </button>
   <button type ="submit"> DOCUMENTOS </button>
   </div>
   <div class ="container-3">
   <button type ="submit"> PROJETOS </button>
   <button type ="submit"> ESCALA </button>
   <button type ="submit"> GERAR AT/BACK </button>
   <button type ="submit"> CONFIGURAÇÃO </button>
     
  </div>
</center>


<script> function myFunction() {
    var popup = document.getElementById('myPopup');
    popup.classList.toggle('show');
}
</script>

