select cw_usuarios.nome as pm_que_atendeu,cw_insercao.* 
from cw_usuarios inner join cw_insercao
on cw_usuarios.matricula=cw_insercao.matricula where cw_usuarios.matricula='305267058';

select * from cw_insercao;

select * from cw_usuarios;
