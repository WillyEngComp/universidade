insert into ocorrencias values('963759486','123','Vitória da Conquista','Bruno Barcelar','Rua Alice Pedral',
'2550','2016','Maio','05','Atentado ao Pudor','Fulano de tal',
'1995','Abril','12','Testemunha');
insert into ocorrencias values('963759486','1234','Vitória da Conquista','Cruzeiro','Rua Antonio Dantas',
'25230','2015','Agosto','13','Homicídio','Ciclano',
'2000','Abril','18','Testemunha');
insert into ocorrencias values('963759486','124323','Vitória da Conquista','Alto Panorama','Av.2 de Julho',
'21234','2016','Junho','14','Ameaça','Rodrigo Teixeira',
'1997','Fevereiro','25','Vítima');
insert into ocorrencias values('754125965','42343','Anagé','Bruno Barcelar','Rua Antonio Dantas',
'4590','2014','Julho','21','Atentado ao Pudor','Raira Carvalho',
'1995','Abril','20','Autor');
insert into ocorrencias values('852456753','123232','Vitória da Conquista','Cruzeiro','Av.2 de Julho',
'2550','2016','Agosto','08','Ameaça','Vinicius dos Santos',
'1998','Abril','11','Vítima');
insert into ocorrencias values('123456789','124243','Vitória da Conquista','Alto Panorama','Rua Alice Pedral',
'2550','2016','Setembro','01','Ameaça','Alisson Oliveira',
'1999','Abril','06','Outros');